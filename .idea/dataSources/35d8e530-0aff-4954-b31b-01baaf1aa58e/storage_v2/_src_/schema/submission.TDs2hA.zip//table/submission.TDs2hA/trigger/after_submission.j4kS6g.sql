create definer = ``@`` trigger after_submission
    after insert
    on submission
    for each row
begin

-- 触发器开始

update review_submission_mapping set state = 1 where new.state = 4 ;



end;

